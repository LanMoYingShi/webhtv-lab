# 选集为空修复

## 根因

`VideoActivity` 在历史续播、跨源续播和详情页模式切换时，使用了历史对象中的旧 `Flag` 实例。合并上游后，当前线路列表中的 `Flag` 可能是同名但不同实例；旧逻辑在 `onItemClick(Flag)` 遇到 `isSelected()` 时直接返回，导致 `setEpisodeAdapter(...)` 没有执行。于是线路按钮已经显示，而选集 RecyclerView 没有任何条目。沉浸融合和详情直放走了显式/缓存播放入口，所以没有触发同一缺陷。

## 修复内容

- 用 `TmdbUIAdapter.selectPlaybackFlag(...)` 将历史线路重新解析为当前 adapter 持有的线路实例，并支持重复线路名。
- 保存并恢复稳定的线路键 `sourceBindingKey`，避免上游刷新或多个同名线路时错配。
- 所有历史恢复、显式选集和线路切换入口统一走当前线路实例，再调用 `setEpisodeAdapter(...)`。
- 续播 payload 使用 `HistoryResumePayload`，避免只传数据库 key 时丢失跨源/线路绑定信息。

## 应用前提

此包是覆盖层源码补丁，需应用到已经合并 `fish2018/webhtv` 上游提交 `dfdb977bd18c3359e939614464c44b83964ba494`（或其后续版本）的完整工程。附件本身不含完整 Gradle 工程、上游数据库迁移和依赖文件，因此不能仅凭此覆盖层单独生成 APK。

## 验证

已静态检查 `VideoActivity.java`：大括号平衡；历史恢复、线路解析、稳定线路键和选集 adapter 调用均存在；旧的 `onItemClick(mHistory.getFlag())` 路径已移除。
