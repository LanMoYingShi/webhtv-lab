package com.fongmi.android.tv.content;

import android.app.Activity;
import android.text.TextUtils;

import com.fongmi.android.tv.bean.Episode;
import com.fongmi.android.tv.bean.GameSourceConfig;
import com.fongmi.android.tv.bean.Result;
import com.fongmi.android.tv.ui.web.GameWebActivity;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.List;
import java.util.Map;

/**
 * 实验室：小游戏内容处理器（对齐 ReaderContentHandler）。
 *
 * 消费「动作卡片」协议（与影视+ VodPlus 的 action 卡片兼容）：
 * 卡片 vod_id 即 JSON：{"actionId":"browser","type":"browser","url":"https://...","title":"小游戏","header":{...}}
 * 配合 vod_tag:'action'，点击卡片时无需进详情页、无需 playerContent 解析，
 * 直接取内嵌 url 用内置 WebView（GameWebActivity）运行游戏。
 *
 * 站点命中判定走 GameSourceConfig（默认规则 [游戏] / [小游戏]）；
 * vod_id 不是 action JSON（如游戏站的普通详情卡）时返回 false，回退原详情页流程。
 */
public class GameContentHandler implements ContentHandler {

    private static final String GAME_URL_PREFIX = "game://";

    @Override
    public boolean canHandleSite(String key, String name) {
        return GameSourceConfig.isSiteEnabled(key, name);
    }

    @Override
    public boolean canHandleUrl(String url) {
        return url != null && url.trim().startsWith(GAME_URL_PREFIX);
    }

    @Override
    public boolean handleSite(Activity activity, String key, String id, String name, String pic, String mark) {
        if (!canHandleSite(key, name)) return false;
        String url = actionUrl(id);
        if (TextUtils.isEmpty(url)) return false; // 非 action 卡片 → 走原详情页
        GameWebActivity.start(activity, url, name, null, actionHeaders(id));
        return true;
    }

    @Override
    public boolean handleUrl(Activity activity, String url, String title) {
        if (!canHandleUrl(url)) return false;
        String target = url.trim().substring(GAME_URL_PREFIX.length()).trim();
        if (TextUtils.isEmpty(target)) return false;
        GameWebActivity.start(activity, target, title, null, null);
        return true;
    }

    @Override
    public boolean handleResult(Activity activity, String historyKey, String siteKey, String flag,
                                String vodName, String vodPic, List<Episode> episodes, int position,
                                Result result, long timeout) {
        return false; // 小游戏不接管播放结果
    }

    /** 从动作卡片 vod_id JSON 中提取游戏 url；非 JSON 或无 url 返回 null。 */
    static String actionUrl(String id) {
        JsonObject obj = actionJson(id);
        if (obj == null) return null;
        JsonElement url = obj.get("url");
        if (url == null || !url.isJsonPrimitive()) return null;
        String value = url.getAsString().trim();
        return value.isEmpty() ? null : value;
    }

    /** 从动作卡片 vod_id JSON 中提取 header（含 User-Agent）；无返回 null。 */
    static java.util.HashMap<String, String> actionHeaders(String id) {
        JsonObject obj = actionJson(id);
        if (obj == null) return null;
        JsonElement header = obj.get("header");
        if (header == null || !header.isJsonObject()) return null;
        java.util.HashMap<String, String> map = new java.util.HashMap<>();
        for (Map.Entry<String, JsonElement> entry : header.getAsJsonObject().entrySet()) {
            if (entry.getValue() != null && entry.getValue().isJsonPrimitive()) {
                map.put(entry.getKey(), entry.getValue().getAsString());
            }
        }
        return map.isEmpty() ? null : map;
    }

    private static JsonObject actionJson(String id) {
        if (TextUtils.isEmpty(id)) return null;
        String s = id.trim();
        if (!s.startsWith("{") || !s.endsWith("}")) return null;
        try {
            JsonElement el = JsonParser.parseString(s);
            if (el != null && el.isJsonObject()) return el.getAsJsonObject();
        } catch (Throwable ignore) {
        }
        return null;
    }
}
